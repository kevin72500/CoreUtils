# CoreUtil
## How to use it

- pip install khandytool
- from core.bladeTest import interactive
- interactive.run(8899)

## Purpose 
This core mainly to personal use, and it just wraped some other packages. the perpose that is make some functions are easy to use quickly.
## Main utils
### 1. blade chaose executer(may have problem by install by pip and run; but ok in deply by source)
which have two models to execute ChaoseBlade command in the remote server
### 2. transfer xmind testcase to excel testcase(some formated restrict xmind)
### 3. transfer swagger url to jmeter scripts
using some opensource packge to complish this

### 4. others code snips like:
- get data from jmesh
- get fack data
- generate test case from xmind
- get sha1 password
- run sql in mysql
- time counter wraper
- multi list to single list
  
### 5. next step plan to add some redis connection or kafka connection or fake data generator into this -- done kafka and fake data

### 6. next step plan to add some redis connnection or mqtt sender or reciever into this or har2locust or other protocol sender...

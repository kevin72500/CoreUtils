# CoreUtil
## Purpose 
This core mainly to personal use, and it just wraped some other packages. the perpose that is make some functions are easy to use quickly.
like:
- get data from jmesh
- get fack data
- generate test case from xmind
- get sha1 password
- run sql in mysql
- time counter wraper
- multi list to single list




import Faker
def out():
    print('this is test')